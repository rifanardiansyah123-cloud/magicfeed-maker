# MagicFeed Maker — PRO STUDIO

Aplikasi pembuat carousel Instagram berbasis React + Vite. Hosting frontend di GitHub Pages, penyimpanan proyek menggunakan IndexedDB, dan AI menggunakan Gemini API melalui Cloudflare Worker.

## Fitur

- Editor carousel dengan maksimal 10 slide.
- Slide hook, content, dan CTA.
- Tambah, hapus, duplikat, serta ubah urutan slide (drag-and-drop pada daftar slide).
- Enam preset visual.
- Rasio 4:5 dan 1:1.
- Pengaturan ukuran headline.
- Branding username, verified badge, avatar, dan toggle branding.
- AI generator untuk 3–10 slide, pilihan niche, caption, dan gambar referensi.
- Caption manager.
- Grid Planner 3×3.
- Simpan/buka/hapus proyek lokal melalui IndexedDB.
- Ekspor satu slide PNG atau semua slide ZIP.
- API key tidak disimpan di frontend.

## 1. Jalankan di komputer (opsional)

Perlu Node.js versi LTS.

```bash
npm install
npm run dev
```

## 2. Deploy ke GitHub Pages

1. Buat repository GitHub baru, misalnya `magicfeed-maker`.
2. Upload semua isi folder proyek ini ke root repository.
3. Buka **Settings → Pages**.
4. Pada **Build and deployment**, pilih **GitHub Actions**.
5. Tambahkan file workflow berikut di `.github/workflows/deploy.yml` (buat folder bila belum ada):

```yaml
name: Deploy MagicFeed Maker
on:
  push:
    branches: [main]
  workflow_dispatch:
permissions:
  contents: read
  pages: write
  id-token: write
concurrency:
  group: pages
  cancel-in-progress: true
jobs:
  build:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - uses: actions/setup-node@v4
        with:
          node-version: 20
          cache: npm
      - run: npm install
      - run: npm run build
      - uses: actions/upload-pages-artifact@v3
        with:
          path: dist
  deploy:
    environment:
      name: github-pages
      url: ${{ steps.deployment.outputs.page_url }}
    runs-on: ubuntu-latest
    needs: build
    steps:
      - uses: actions/deploy-pages@v4
        id: deployment
```

4. Simpan/commit. Tunggu workflow selesai. URL aplikasi biasanya `https://USERNAME.github.io/NAMA-REPOSITORY/`.

## 3. Pasang AI gratis melalui Cloudflare Worker

AI memerlukan Gemini API key. Free tier dapat berubah, memiliki batas penggunaan, dan tidak dijamin selalu tersedia.

1. Buat API key di Google AI Studio: https://aistudio.google.com/app/apikey
2. Buat akun Cloudflare lalu buka Workers & Pages.
3. Buat Worker baru bernama `magicfeed-ai`.
4. Ganti isi kode Worker dengan `worker/index.js` dari proyek ini.
5. Di pengaturan Worker → **Settings → Variables and Secrets**, tambahkan Secret:
   - Name: `GEMINI_API_KEY`
   - Value: API key dari Google AI Studio
6. Tambahkan variable `GEMINI_MODEL` = `gemini-2.5-flash-lite` (atau model teks Gemini yang tersedia di akun Anda).
7. Tambahkan variable `ALLOWED_ORIGIN` dengan URL GitHub Pages Anda, misalnya `https://USERNAME.github.io`. Jika memakai custom domain, masukkan origin custom domain.
8. Deploy Worker. Catat URL Worker, misalnya `https://magicfeed-ai.NAMA-AKUN.workers.dev`.
9. Buka aplikasi → Pengaturan → masukkan URL Worker → Simpan URL Worker.

> Untuk uji awal, `ALLOWED_ORIGIN = "*"` dapat dipakai sementara. Setelah URL GitHub Pages diketahui, ubah ke origin yang tepat. Jangan pernah memasukkan Gemini API key ke source code frontend, GitHub repository, atau kolom URL Worker.

## 4. Catatan penting

- Penyimpanan `local` berarti data tersimpan pada browser/perangkat yang sama. Data tidak otomatis tersinkron ke perangkat lain.
- Jangan hapus data situs/browser jika ingin mempertahankan proyek lokal.
- Ekspor ZIP menghasilkan file PNG per slide.
- AI menggunakan Gemini 2.5 Flash-Lite secara default. Jika model tidak tersedia untuk akun/region Anda, ganti `GEMINI_MODEL` pada Cloudflare Worker ke model teks yang tersedia di Google AI Studio.
- Batas free tier dan kebijakan privasi Google dapat berubah. Jangan kirim data sensitif ke AI.
- Ini adalah fondasi aplikasi yang dapat dikembangkan lebih lanjut; lakukan uji ekspor dan koneksi Worker setelah deploy.

## Struktur

```text
magicfeed-maker-pro/
├── index.html
├── package.json
├── vite.config.js
├── README.md
├── .github/workflows/deploy.yml
├── src/
│   ├── main.jsx
│   ├── App.jsx
│   └── style.css
└── worker/
    ├── index.js
    └── wrangler.toml
```
